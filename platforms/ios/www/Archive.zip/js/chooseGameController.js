angular.module('app.chooseGameController', [])

.controller('gamesDrills', ['$scope', '$stateParams', '$timeout', '$ionicPopup',
   '$http', '$location', '$state', '$ionicHistory', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function($scope, $stateParams, $timeout, $ionicPopup, $http, $location, $state, $ionicHistory, $window) {


  $scope.base = "Connecting to base station...";
  $scope.base_msg_window = false;
  $scope.scorelimit = 15;

  $scope.doRefresh = function() {
    $state.go($state.current, {}, {reload: true});
       // Stop the ion-refresher from spinning
    $scope.$broadcast('scroll.refreshComplete');
    $window.location.href='/#/page1/page2';
 
  };
  $scope.game_types;

  // get game types
    $http({method: 'GET', url: "http://"+ip+":"+port+"/?page=game_types&json_callback=JSON_CALLBACK"}).
      success(function(data, status) {
        
        $scope.game_types = angular.fromJson(data);
        console.log($scope.game_types);
 
        $scope.base_msg_window = false;
               
      }).
      error(function(data, status) {
        console.log("Could not talk to base station");
        $scope.base_msg = "Not connected to base station";
        $scope.base_msg_window = true;
    }); 
/*
select game_type.game_type_id, game_name, game_type_rules_id, game_type_rules.game_type_attribute_id, attribute_name, attribute_value
from game_type, game_type_rules, game_type_attribute , game_type_attribute_value
where game_type.game_type_id = game_type_rules.game_type_id and game_type_attribute.game_type_attribute_id = game_type_rules.game_type_attribute_id
and game_type_attribute.game_type_attribute_id = game_type_attribute_value.game_type_attribute_id;
*/
  $scope.card_objective = "";
  $scope.choose_game = "Choose Game or Drill";
  $scope.image = "";
 
  $scope.showcardspace = false;
  $scope.showSpeed = false;
  $scope.showplayers = false;
  $scope.showPaddleSequence = false;
  $scope.showMaxTimeLabel = false;
  $scope.showScoreLimitLabel = false;
  $scope.showDoubleTapOption = false;
  $scope.showTargetTimeoutOPtion = false;
 
	var manager = io.Manager('http://'+ip+':'+port+'/', { /* options */ });
	manager.socket('/namespace');
	manager.on('connect_error', function() {
     $scope.$apply(function () {
        $scope.base_msg = "Not connected to base station";
        $scope.base_msg_window = true;
     });
	});

  // setup sockets
  var socket = io.connect('http://'+ip+':'+port+'/');
 
   socket.on('jsonrows', function(data){
       $scope.activity = angular.fromJson(data);
       console.log($scope.activity);
       $scope.$apply(function () {

       $scope.player_names = $scope.activity.players;
     });
   });

   $scope.$on('$destroy', function (event) {
    socket.removeAllListeners();
   })
 
  // host fired off goToPage broadcast. 
  // this is the echo back and redirects all devices to game screen
	socket.on('goToPageBroadcast', function(data){
 
      $scope.game_data = angular.fromJson(data);


      $ionicHistory.clearCache().then(function(){
        $state.go('game', {gameid: $scope.game_data.gamename, maxtime: $scope.game_data.maxtime, 
        max_targets: $scope.game_data.max_targets,
        paddle_sequence: $scope.game_data.paddle_sequence, speed: $scope.game_data.speed, 
        double_tap: $scope.game_data.double_tap, target_timeout: $scope.game_data.target_timeout,
        matchtype: $scope.matchtype, scorelimit: $scope.scorelimit,
        player_list: $scope.game_data.player_list }, {reload: true});
      });
 
  });
 
    //$scope.maxtime = "120";
    // Select dropdown options on screen
    $scope.showMaxTime = function(maxtime) {
      console.log("max time: " + maxtime);
      $scope.maxtime = maxtime;
    }

    $scope.showScoreLimit = function(scorelimit) {
      console.log("score limit: " + scorelimit);
      $scope.scorelimit = scorelimit;
    }

    $scope.showmatchtype = function(matchtype) {

      console.log("matchtype: " + matchtype);
      if (matchtype == "Single player")
      {
        $scope.showplayers = true;
        $scope.join_players = "Join a player to the game";
        $scope.radio_list_players = true;
        $scope.checkbox_list_players = false;
      }
      if (matchtype == "1 vs 1")
      {
        $scope.showplayers = true;
        $scope.join_players = "Join players to the game";
        $scope.checkbox_list_players = true;
        $scope.radio_list_players = false;
      }
      if (matchtype == "Team vs Team")
      {
        $scope.showplayers = true;
        $scope.join_players = "Join players to the game";
      }
      // reset for when user bounces back and forth with match types
      $scope.player_list = [5];

      $scope.matchtype = matchtype;

    }

    $scope.showMaxTargets = function(max_target) {
      console.log("max targets: " + max_target);
      $scope.max_target = max_target;
    }
    
    //$scope.speed = "800";
    $scope.updateSpeed = function(set_speed) {
      console.log("speed: " + set_speed);
      $scope.set_speed = set_speed;
    }

    $scope.player_list = []; // array of players
    $scope.add_player_to_game = function(val){
        console.log("Player id : " + val);
        
        if ($scope.matchtype == "Single player" || $scope.player_list[0] == 5) // just clear array each time and start fresh
        {
          $scope.player_list = [];
        }
        


        // splicing handles checking and unchecking of checkboxes
        index = $scope.player_list.indexOf(val); // find player in array
        console.log("index: " + index);
        if (index > -1) {
            $scope.player_list.splice(index, 1); // remove player from array
        }
        else
        {
          $scope.player_list.push(val); // add player into array

        }

        console.log(index);
        console.log($scope.player_list);
    }

    $scope.paddle_sequence = "Randomize";  
    $scope.udpatePaddleSequence = function(set_paddle_sequence) {
      console.log("paddle sequence: " + set_paddle_sequence);
      $scope.set_paddle_sequence = set_paddle_sequence;
    }

  
    $scope.double_tap = "false";
    $scope.showDoubleTap = function(double_tap) {
      console.log("doubleTap: " + double_tap);
      $scope.double_tap = double_tap;
    }
    $scope.target_timeout = "false";
    $scope.showTargetTimeout = function(target_timeout) {
      console.log("Target Timeout: " + target_timeout);
      $scope.target_timeout = target_timeout;
    }



    // package up game parameters, send it to base station to 
    // echo back to all other devices for redirect to game screen
    $scope.goToGame = function($rootScope) {
   
  
 
        var gameParameters = {};
        gameParameters['gamename'] = $scope.data.gamename;
        if ($scope.maxtime > 0)
          gameParameters['maxtime'] = $scope.maxtime;
        else
          gameParameters['maxtime'] = 120; // the default
        if ($scope.max_target > 0)
          gameParameters['max_targets'] = $scope.max_target;
        else
          gameParameters['max_targets'] = 2;

        gameParameters['scorelimit'] = $scope.scorelimit; // default
        if ($scope.scorelimit > 0)
          gameParameters['scorelimit'] = $scope.scorelimit;
        else
          gameParameters['scorelimit'] = "nolimit";
        if ($scope.set_paddle_sequence > 0)
        gameParameters['paddle_sequence'] = $scope.set_paddle_sequence;
        else
          gameParameters['paddle_sequence'] = 'Randomize';
        if ($scope.set_speed > 0)
          gameParameters['speed'] = $scope.set_speed;
        else
          gameParameters['speed'] = 500;
        gameParameters['double_tap'] = $scope.double_tap;
        gameParameters['target_timeout'] = $scope.target_timeout;
        if ($scope.player_list.length == 0)
            $scope.player_list.push(5);
        gameParameters['player_list'] = $scope.player_list;
       // gameParameters['matchtype'] = 'Co-op'; // default
       gameParameters['matchtype'] = $scope.matchtype; // default

    
        var err = 0;
        if ($scope.player_list[0] == 5 && $scope.matchtype == 'Single player'){
          //showChoosePlayer();
          err = 1;
          var alertPopup = $ionicPopup.alert({
            title: 'Please add a player to the game',
        
          });
        } 
        if ($scope.player_list.length < 2 && $scope.matchtype == '1 vs 1'){
          //showChoosePlayer();
          err = 1;
          var alertPopup = $ionicPopup.alert({
            title: 'Two players required for 1 vs 1',
     
          });
        } 
          
        if (!err){
          console.log(gameParameters['matchtype']);
          console.log(gameParameters);
          socket.emit( 'goToPage', JSON.stringify(gameParameters) ); 
        }


    }
 
      
 
    

    $scope.showGameListPopup = function() {
      $scope.data = {};
      

      $scope.radio_list = '';
      for (var i=0; i<$scope.game_types.length; i++)
      {
        $scope.radio_list += '<ion-radio  ng-model="data.gamename" ng-value="\'' + $scope.game_types[i]['game_name'] + '\'">'+$scope.game_types[i]['game_name']+'</ion-radio>';
      }


      var confirmPopup = $ionicPopup.confirm({
         title: 'Select a Game',
         template: $scope.radio_list,

          scope: $scope
      });

      confirmPopup.then(function(res) {

        
         if(res) { // Ok button clicked



          // display game type information once selected
          for (var i=0; i<$scope.game_types.length; i++)
          {
            if ($scope.game_types[i]['game_name'] == $scope.data.gamename)
            {
                // get game options from game_rules table
                $http({method: 'GET', url: "http://"+ip+":"+port+"/?page=game_rules&game_type_id="+$scope.game_types[i]['game_type_id']+"&json_callback=JSON_CALLBACK"}).
                  success(function(data, status) {
                    
                    $scope.game_rules = angular.fromJson(data);
                    console.log($scope.game_rules);
             
                    $scope.set_speed = 500;
                    $scope.matchtypes = [];
                    $scope.max_targets = [];
                    $scope.maxtimes = [];
                    $scope.speed = [];
                    $scope.scorelimits = [];
                    $scope.paddle_sequence = [];
                    for (var i=0; i<$scope.game_rules.length; i++)
                    {
                        
                      /* the matchtype options
                        $scope.matchtypes = [
                          {name: 'Single player', id:1 },
                          {name: 'Co-op', id:2 },
                          {name: '1 vs 1', id:3 }
                        ];
                      */

                      if ($scope.game_rules[i]['attribute_name'] == "Match type")
                      {
                        
                          $scope.matchtypes.push({name: $scope.game_rules[i]['attribute_value'], id: $scope.game_rules[i]['game_type_attribute_value_id']});
                          $scope.matchtype = $scope.matchtypes[1]; // set a default selection
                      }

                      if ($scope.game_rules[i]['attribute_name'] == "Max hits")
                      {
                        //console.log($scope.game_rules[i]['attribute_name']);
                        $scope.max_targets.push({name: $scope.game_rules[i]['attribute_value'], id: $scope.game_rules[i]['attribute_value'] });
                        $scope.max_target = $scope.max_targets[0]; // set a default selection
                      }

                      if ($scope.game_rules[i]['attribute_name'] == "Max time")
                      {
                        $scope.showMaxTimeLabel = true;
                        $scope.maxtimes.push({name: $scope.game_rules[i]['attribute_value'], id: $scope.game_rules[i]['attribute_value_2'] });
                        $scope.maxtime = $scope.maxtimes[2]; // set a default selection
                      }

                      if ($scope.game_rules[i]['attribute_name'] == "Score limit")
                      {
                        console.log("here: " + $scope.game_rules[i]['attribute_value']);
                        $scope.showScoreLimitLabel = true;
                        $scope.scorelimits.push({name: $scope.game_rules[i]['attribute_value'], id: $scope.game_rules[i]['attribute_value'] });
                        $scope.scorelimit = $scope.scorelimits[2]; // set a default selection
                      }

                      if ($scope.game_rules[i]['attribute_name'] == "Speed")
                      {
                        $scope.showSpeed = true;
                        console.log($scope.game_rules[i]['attribute_value']);
                        $scope.speed.push({name: $scope.game_rules[i]['attribute_value'], id: $scope.game_rules[i]['attribute_value_2'] });
                        $scope.set_speed = $scope.speed[7]; // set a default selection
                      }
                      

                      if ($scope.game_rules[i]['attribute_name'] == "Double tap")
                      {

                        $scope.showDoubleTapOption = true;
                        console.log($scope.game_rules[i]['attribute_value']);
     
                      }

                      if ($scope.game_rules[i]['attribute_name'] == "Paddle sequence")
                      {
                        $scope.showPaddleSequence = true;
                        console.log($scope.game_rules[i]['attribute_value']);
                        $scope.paddle_sequence.push({name: $scope.game_rules[i]['attribute_value'], id: $scope.game_rules[i]['attribute_value'] });
                        $scope.set_paddle_sequence = $scope.paddle_sequence[0]; // set a default selection
                      }
                      if ($scope.game_rules[i]['attribute_name'] == "Target timeout")
                      {
                        $scope.showTargetTimeoutOption = true;
                        console.log($scope.game_rules[i]['attribute_value']);
           
                      }
                      

     
                      
                    } 
                    

                   
                           
                  }).
                  error(function(data, status) {
                    console.log("Could not talk to base station");
                }); 


               $scope.card = $scope.game_types[i]['game_name'];
               $scope.card_objective = $scope.game_types[i]['game_description'];
               $scope.image=$scope.game_types[i]['game_image'];
               $scope.image='game-swarm.jpg';

               $scope.showcardspace = true;
            }
             
          }

          $scope.choose_game = $scope.data.gamename;
           
         } else {
           console.log('You are not sure');
         }
      });


   };


}])


.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
 

  });
})
 