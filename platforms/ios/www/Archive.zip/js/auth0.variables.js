// var AUTH0_CLIENT_ID='HFDoRtAWuAKNBhxDQrGm3XAGcEgRH13t';
// var AUTH0_CALLBACK_URL=location.href;
// var AUTH0_DOMAIN='mark-campbell.auth0.com';
var port = '8081';
var ip = '192.168.8.1';
//var ip = '192.168.7.2';
//var ip ="12";
var profile_auth0_name = "Guest";