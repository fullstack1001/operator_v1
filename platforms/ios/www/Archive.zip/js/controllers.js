angular.module('app.controllers', [])
  
.controller('gamesDrillsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('scoresCtrl', ['$scope', '$stateParams', '$state', '$http',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, $http) {
 
	// **** setup vars ******
	$scope.prevgames=true;
	var stats = {};
	stats = [];
	var socket = io.connect('http://'+ip+':'+port+'/');
  $scope.fastest_split = 100;
  $scope.fastest_split_p2 = 100;
  $scope.fastest_response = 100;
  $scope.fastest_response_p2 = 100;
  $scope.avg_split = 0;
  $scope.avg_split_p2 = 0;
  $scope.avg_response = 0;
  $scope.avg_response_p2 = 0;
  $scope.show_avg_split = false;
  $scope.show_best_split = false;
  $scope.show_all_splits = false;
  $scope.show_avg_response = true;
  $scope.show_most_hits = false;
	// END **** setup vars ******





  //$scope.labels = ["Shot 1", "Shot 2", "Shot 3", "Shot 4", "Shot 5", "Shot 6", "Shot 7"];
 
  
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.colors = ['#FF3100', '#1300D7', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'];
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' } ];

  $scope.options = {
    legend: {display: true},
    scales: {
      yAxes: [
        {
          scaleLabel: {
            display: true,
            labelString: 'Time in seconds'
          },
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left',
          labelString: 'Time in seconds'
        } 
        
      ]
    }
  };




 
//result_data_last_round

	// get results
	$http({method: 'GET', url: "http://"+ip+":"+port+"/?page=last_game_results&json_callback=JSON_CALLBACK"}).
	    success(function(data, status) {
	      
	     
	      $scope.result_data_arr = angular.fromJson(data);
        $scope.result_data_last_round = $scope.result_data_arr[1];
        $scope.result_data = $scope.result_data_arr[0];

        $scope.match_type = $scope.result_data_arr[0][0].match_type;

	      $scope.stats = $scope.result_data;
        $scope.stats_last_round = $scope.result_data_last_round;
	       
	      $scope.paddles_served = 0;
        $scope.paddles_hit = 0;
        $scope.paddles_served_p2 = 0;
        $scope.paddles_hit_p2 = 0;
        $scope.shot_time_arr = [];
        $scope.shot_time_arr_p2 = [];
        $scope.shot_time_arr_avg = []; //Math.random() * (max - min) + min;
        $scope.shot_time_arr_last_round = [];
        $scope.shot_cnt_arr = [];
        $scope.shot_cnt_arr_p2 = [];
        $scope.shot_cnt_incrementer = 1;
        $scope.shot_cnt_incrementer_p2 = 1;
 


        // gather multiplayer names
        $scope.matchtype =  $scope.result_data_arr[0][0].player_name;

        if ($scope.match_type == "1 vs 1")
        {
          // for multiplayer - get counters and player names
          $scope.player1_incrementer = 0;
          $scope.player2_incrementer = 0;
          $scope.player1 = $scope.result_data_arr[0][0].player_name;

          
          // get player2 name
          for (var i=0; i<$scope.result_data.length; i++)
          { 
             if ($scope.player1 != $scope.result_data[i].player_name){
              $scope.player2 = $scope.result_data[i].player_name;
              break;
            }
          }
          // display names on client 
          $scope.matchtype =   " " + $scope.player1 + ' vs ' + $scope.player2;
          $scope.player_column = true;
          $scope.show_most_hits = true;
        }
        console.log("Matchtype: " +$scope.matchtype);
        // package up hit detail log into stats[] array and do summary data math
	      for (var i=0; i<$scope.result_data.length; i++)
          {
            
            if ($scope.result_data[i].target_hit_time > 1)
            {
              // for detail hit log
              $scope.stats[i].time_till_hit = msToTimeShort(($scope.result_data[i].target_hit_time - $scope.result_data[i].current_seconds)/10);
              // count up average hit responses
              $scope.avg_response += parseFloat($scope.stats[i].time_till_hit);
            }
            else
            {
              $scope.stats[i].time_till_hit = "miss";
              $scope.avg_response += 0;
            }
            // fastest response
            if($scope.stats[i].time_till_hit < $scope.fastest_response)
            {
              $scope.fastest_response = $scope.stats[i].time_till_hit;
              if ($scope.match_type == "1 vs 1")
              {
                $scope.fastest_response += ' -' + $scope.stats[i].player_name;
                $scope.show_avg_response = false;
              }
            }
            console.log($scope.player_id);
            

            // charting
            if ($scope.result_data[i].target_hit == 1)
            {
              if ($scope.match_type == "1 vs 1")
              { 

                if ($scope.stats[i].player_name == $scope.player1)
                {
                  $scope.shot_time_arr[$scope.player1_incrementer] = parseFloat($scope.stats[i].time_till_hit);
                  $scope.shot_cnt_arr[$scope.player1_incrementer] = 'Shot '+ $scope.shot_cnt_incrementer++;
                  $scope.player1_incrementer++;

                }
                else if ($scope.stats[i].player_name == $scope.player2)
                { 
                  
                    $scope.shot_time_arr_p2[$scope.player2_incrementer] = parseFloat($scope.stats[i].time_till_hit);
                    $scope.shot_cnt_arr_p2[$scope.player2_incrementer] = 'Shot '+ $scope.shot_cnt_incrementer_p2++;
                    $scope.player2_incrementer++;

                }
                

              }
              else
              {
                $scope.shot_time_arr[i] = parseFloat($scope.stats[i].time_till_hit);
                $scope.shot_cnt_arr[i] = 'Shot '+ $scope.shot_cnt_incrementer++;    
              } 
            }


            $scope.stats[i].target_hit_time = msToTimeShort($scope.result_data[i].target_hit_time/10);
            
            $scope.stats[i].split_time = msToTimeShort($scope.result_data[i].target_split_time/10);

            // count up average splits
            $scope.avg_split += parseFloat(msToTimeShort($scope.result_data[i].target_split_time/10));

            // display most hits
            if ($scope.match_type == "1 vs 1")
            {
              if($scope.player1_incrementer > $scope.player2_incrementer)
              {
                $scope.most_hits = $scope.player1_incrementer + ' -' +$scope.player1;
              }
              else
              {
                $scope.most_hits = $scope.player2_incrementer + ' -' + $scope.player2;
              }
            }
            // fastest split
            if ($scope.match_type == "1 vs 1")
            {
              //$scope.fastest_split = $scope.stats[i].split_time ;
            }
            else
            {
              $scope.fastest_split = $scope.stats[i].split_time;
            }
     

            
            $scope.stats[i].target_presented = $scope.result_data[i].target_presented;

            $scope.stats[i].player_name = $scope.result_data[i].player_name;
            
            // hits vs serves
            if ($scope.match_type == "1 vs 1")
            { 
              if ($scope.stats[i].player_name == $scope.player1)
              {
                // count serves vs hits
                $scope.paddles_served++;
                if ($scope.result_data[i].target_hit == 1)
                  $scope.paddles_hit++;
              }
              else if ($scope.stats[i].player_name == $scope.player2)
              {
                 $scope.paddles_served_p2++;
                if ($scope.result_data[i].target_hit == 1)
                  $scope.paddles_hit_p2++;
              }
              

            }
            else
            {
              // count serves vs hits
              $scope.paddles_served++;
              if ($scope.result_data[i].target_hit == 1)
                $scope.paddles_hit++;  
            } 
            


            // just get last hit to calculate completion time in game
            $scope.completed_game_time = msToTime($scope.result_data[i].target_hit_time*100);
            // not working
            $scope.average_hit_time =  $scope.stats[i].time_till_hit;
            $scope.gamename = $scope.result_data[i].game_name;

            

          } 



          // if current game was not 1v1, then show previous game shot time results in 
          // chart for comparison of current game
          console.log($scope.result_data_last_round);
          for (var i=0; i<$scope.result_data_last_round.length; i++)
          {

            $scope.player_name_last_round = $scope.stats_last_round[i].player_name;
            if ($scope.stats_last_round[i].target_hit_time > 1)
              $scope.stats_last_round[i].time_till_hit = msToTimeShort(($scope.stats_last_round[i].target_hit_time - $scope.stats_last_round[i].current_seconds)/10);
            else
              $scope.stats_last_round[i].time_till_hit = 0;
              console.log($scope.stats_last_round[i].time_till_hit);
            // charting
            $scope.shot_time_arr_last_round[i] = parseFloat($scope.stats_last_round[i].time_till_hit);    
 
          }   

          // calculate split times
          if ($scope.match_type == "1 vs 1")
          {
            $scope.avg_split = ($scope.avg_split / $scope.paddles_hit).toFixed(2);
            if ($scope.avg_split > 0)
              $scope.show_avg_split = true;
            if ($scope.fastest_split > 0)
              $scope.show_best_split = true;
            if ($scope.best_split > 0)
              $scope.show_all_splits = true;

            $scope.avg_split = ($scope.avg_split / $scope.paddles_hit).toFixed(2);
            if ($scope.avg_split > 0)
              $scope.show_avg_split = true;
            if ($scope.fastest_split > 0)
              $scope.show_best_split = true;
  
          }
          else
          {
            $scope.avg_split = ($scope.avg_split / $scope.paddles_hit).toFixed(2);
            if ($scope.avg_split > 0)
              $scope.show_avg_split = true;
            if ($scope.fastest_split > 0)
              $scope.show_best_split = true;
            if ($scope.best_split > 0)
              $scope.show_all_splits = true;
          }
          

 
          // calculate average response
          if ($scope.paddles_hit > 0)
            $scope.avg_response = ($scope.avg_response / $scope.paddles_hit).toFixed(2);

          
          	


          $scope.hits_vs_serves = Math.round(($scope.paddles_hit / $scope.paddles_served)*100) ;
          
 
          // chart data
          if ($scope.match_type == "1 vs 1")
          {
            $scope.series = [$scope.player1, $scope.player2];

            $scope.data = [
              $scope.shot_time_arr
              , $scope.shot_time_arr_p2
            ]; 

          }
          else
          {
            $scope.series = ['Current - ' + $scope.player_name, 'Previous game - ' + $scope.player_name_last_round];

            $scope.data = [
              $scope.shot_time_arr
              , $scope.shot_time_arr_last_round
            ];  
 
          } 
          $scope.labels = $scope.shot_cnt_arr; 
          
	    }).
	    error(function(data, status) {
	      console.log("Get score results failed");
		});

	$http({method: 'GET', url: "http://"+ip+":"+port+"/?page=past_game_results&json_callback=JSON_CALLBACK"}).
	    success(function(data, status) {
	      
	      $scope.result_data = angular.fromJson(data);
	      //console.log($scope.result_data);
	      $scope.items = $scope.result_data;

	      $scope.items.total_game_time = $scope.result_data.total_game_time;
 
	      for (var i=0; i<$scope.result_data.length; i++)
          {

          	// console.log($scope.result_data[i].game_id);
          	// console.log($scope.result_data[i].game_name);
          	// console.log($scope.result_data[i].total_game_time);
          	// console.log($scope.result_data[i].targets_hit);
            //console.log("Avg hit response: " + msToTime($scope.result_data[i].avg_hit_response/10));
            $scope.result_data[i].avg_hit_response = msToTime($scope.result_data[i].avg_hit_response/10);
            $scope.result_data[i].fastest_hit_response = msToTime($scope.result_data[i].fastest_hit_response/10);
            
            if ($scope.result_data[i].date > 0)
            {
              var utcSeconds = parseInt($scope.result_data[i].date);
           
              $scope.result_data[i].date_formatted = timeConverter(utcSeconds);
               
            }
   
          } 


          function timeConverter(UNIX_timestamp){
            var a = new Date(UNIX_timestamp );
            var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            var year = a.getFullYear();
            var month = months[a.getMonth()];
            var date = a.getDate();
            var hour = a.getHours();
            var min = a.getMinutes();
            var sec = a.getSeconds();
            var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
            return time;
          }  
               
	    }).
	    error(function(data, status) {
	      console.log("Get score results failed");
	}); 

  	// check if there is a command to redirect player's screen to the game screen
  	// this occurs when game host hits START on the game screen
  	

  	// host fired off goToPage broadcast. 
  	// this is the echo back and redirects all devices to game screen

	socket.on('goToPageBroadcast', function(data){

	    $scope.game_data = angular.fromJson(data);

      $ionicHistory.clearCache().then(function(){
        $state.go('game', {gameid: $scope.game_data.gamename, maxtime: $scope.game_data.maxtime, 
        max_targets: $scope.game_data.max_targets,
        paddle_sequence: $scope.game_data.paddle_sequence, speed: $scope.game_data.speed, 
        double_tap: $scope.game_data.double_tap, target_timeout: $scope.game_data.target_timeout,
        matchtype: $scope.matchtype, scorelimit: $scope.scorelimit,
        player_list: $scope.game_data.player_list }, {reload: true});
      });

	});


}])
   

.controller('realTimeStatsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('settingsCtrl', ['$scope', '$stateParams', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state) {

	// check if there is a command to redirect player's screen to the game screen
  	// this occurs when game host hits START on the game screen
  	var socket = io.connect('http://'+ip+':'+port+'/');

  	// host fired off goToPage broadcast. 
  	// this is the echo back and redirects all devices to game screen
	socket.on('goToPageBroadcast', function(data){

	    $scope.game_data = angular.fromJson(data);

	     $ionicHistory.clearCache().then(function(){
        $state.go('game', {gameid: $scope.game_data.gamename, maxtime: $scope.game_data.maxtime, 
        max_targets: $scope.game_data.max_targets,
        paddle_sequence: $scope.game_data.paddle_sequence, speed: $scope.game_data.speed, 
        double_tap: $scope.game_data.double_tap, target_timeout: $scope.game_data.target_timeout,
        matchtype: $scope.matchtype, scorelimit: $scope.scorelimit,
        player_list: $scope.game_data.player_list }, {reload: true});
      });

	});

}])
      

.controller('profileCtrl', ['$scope', '$stateParams', '$rootScope', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams,  $rootScope, $state) {
 

	// check if there is a command to redirect player's screen to the game screen
  	// this occurs when game host hits START on the game screen
  	var socket = io.connect('http://'+ip+':'+port+'/');

  	// host fired off goToPage broadcast. 
  	// this is the echo back and redirects all devices to game screen
	socket.on('goToPageBroadcast', function(data){

	    $scope.game_data = angular.fromJson(data);

	     $ionicHistory.clearCache().then(function(){
        $state.go('game', {gameid: $scope.game_data.gamename, maxtime: $scope.game_data.maxtime, 
        max_targets: $scope.game_data.max_targets,
        paddle_sequence: $scope.game_data.paddle_sequence, speed: $scope.game_data.speed, 
        double_tap: $scope.game_data.double_tap, target_timeout: $scope.game_data.target_timeout,
        matchtype: $scope.matchtype, scorelimit: $scope.scorelimit,
        player_list: $scope.game_data.player_list }, {reload: true});
      });

	});



}])
      
.controller('buildRangeCtrl', ['$scope', '$stateParams', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state) {

	// check if there is a command to redirect player's screen to the game screen
  	// this occurs when game host hits START on the game screen
  	var socket = io.connect('http://'+ip+':'+port+'/');

  	// host fired off goToPage broadcast. 
  	// this is the echo back and redirects all devices to game screen
	socket.on('goToPageBroadcast', function(data){

	    $scope.game_data = angular.fromJson(data);

	       $ionicHistory.clearCache().then(function(){
        $state.go('game', {gameid: $scope.game_data.gamename, maxtime: $scope.game_data.maxtime, 
        max_targets: $scope.game_data.max_targets,
        paddle_sequence: $scope.game_data.paddle_sequence, speed: $scope.game_data.speed, 
        double_tap: $scope.game_data.double_tap, target_timeout: $scope.game_data.target_timeout,
        matchtype: $scope.matchtype, scorelimit: $scope.scorelimit,
        player_list: $scope.game_data.player_list }, {reload: true});
      });

	});

}])
   
.controller('downloadCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('home2Ctrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {




  //$scope.goToGameController = function(){
  //  console.log("hi");
  //}




  
	// check if there is a command to redirect player's screen to the game screen
  	// this occurs when game host hits START on the game screen
  	var socket = io.connect('http://'+ip+':'+port+'/');

  	// host fired off goToPage broadcast. 
  	// this is the echo back and redirects all devices to game screen
	socket.on('goToPageBroadcast', function(data){

	    $scope.game_data = angular.fromJson(data);

	      $ionicHistory.clearCache().then(function(){
        $state.go('game', {gameid: $scope.game_data.gamename, maxtime: $scope.game_data.maxtime, 
        max_targets: $scope.game_data.max_targets,
        paddle_sequence: $scope.game_data.paddle_sequence, speed: $scope.game_data.speed, 
        double_tap: $scope.game_data.double_tap, target_timeout: $scope.game_data.target_timeout,
        matchtype: $scope.matchtype, scorelimit: $scope.scorelimit,
        player_list: $scope.game_data.player_list }, {reload: true});
      });

	});


}])
   
.controller('diagnosticsCtrl', ['$scope', '$stateParams', '$state', '$http', '$ionicHistory', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, $http, $ionicHistory) {


  // helps with swipe to go back functionality I think
    $scope.myGoBack = function() {
       $ionicHistory.goBack();
    };
    $scope.swipe = function (direction) {
        $ionicHistory.goBack();
    }
 

  var socket = io.connect('http://'+ip+':'+port+'/');
 
   socket.on('jsonrows', function(data){
      $scope.activity = angular.fromJson(data);
      $scope.$apply(function () {

      $scope.items = $scope.activity.target;
      $scope.targets = $scope.activity.target;

    


       for (var key in $scope.targets)
        {
            $scope.targets[key].online_msg = "Offline";
            $scope.targets[key].volt_percent =0;
            $scope.targets[key].battery_icon = 'icon ion-battery-empty';
            if ($scope.targets[key].online)
            { 
              if ($scope.targets[key].volt === undefined)
                $scope.targets[key].volt_percent = "please wait...";
              else
              {
                  //console.log($scope.targets[key].id);
                var volt_percent = Math.floor((($scope.targets[key].volt - 460)/140)*100)
                //console.log(  Math.floor((($scope.targets[key].volt - 460)/140)*100));
                $scope.targets[key].volt_percent = volt_percent+ '% / adc: ' + $scope.targets[key].volt ;
                if (volt_percent > 5)
                  $scope.targets[key].battery_icon = 'icon ion-battery-low';
                if (volt_percent > 50 )
                  $scope.targets[key].battery_icon = 'icon ion-battery-half';
                if (volt_percent > 85)
                  $scope.targets[key].battery_icon = 'icon ion-battery-full';
              }
              $scope.targets[key].online_msg = "Online";
              

              //console.log($scope.targets[key].id + ' ' + $scope.targets[key].online + ' ' + $scope.targets[key].volt_percent);
            }
            else
            {
              // target is offline - splice from array
              delete $scope.targets[key];
              
            }
        }
 

      
   
     });
   });


  $scope.pingTarget = function($id) {
        console.log("pinging target: " + $id);

        $http({method: 'GET', url: "http://"+ip+":"+port+"/?get=ping&target=" + $id}).
          success(function(data, status) {
             
            console.log("request sent.");
 
          }).
          error(function(data, status) {
            console.log("failed to communicate to base station");
        
        }); 



    }
 


}])
   
.controller('targetInfoCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('loginCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('gameCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
 



