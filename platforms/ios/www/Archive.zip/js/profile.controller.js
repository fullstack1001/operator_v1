
 
angular.module('app.profileController', [])

.controller('profileController', ['$scope', '$stateParams',  '$rootScope',
            '$location', '$state', 'store', '$http', '$timeout', '$cordovaSQLite', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function($scope, $stateParams, $rootScope, $location, $state, store, $http, $timeout, $cordovaSQLite ) {



  var vm = this;

  $scope.msg = "Add a new user";

  vm.addUser = addUser;
 
  function addUser() {
    console.log("adding: " + $scope.username);

    $http({method: 'GET', url: 'http://'+ip+':'+port+'/?page=adduser&name=' + $scope.username + '&callback=JSON_CALLBACK&'}).
          success(function(data, status) {
        
            console.log($scope.username + " added");
            $scope.msg = $scope.username + " added";
            $scope.msg_due = $scope.username + " added";
          }).
          error(function(data, status) {
            console.log("Stop game request failed");
            $scope.msg = "Base station didn't receive: Game stopped by host!";
        }); 


  }

  
  $scope.getUserName = function(username) {
    $scope.username = username;
  }

/*
  vm.auth = auth;
    $scope.sqllitedata = "hello";
    firstname = "Mark";
    lastname = "Campbell";
    $scope.insert = function(firstname, lastname) {
        var query = "INSERT INTO people (firstname, lastname) VALUES (?,?)";
        $cordovaSQLite.execute(db, query, [firstname, lastname]).then(function(res) {
            console.log("INSERT ID -> " + res.insertId);
            $scope.sqllitedata = "inserted";
        }, function (err) {
            console.error(err);
            $scope.sqllitedata = err;
        });
    }
    */
 
    $scope.select = function(lastname) {
        var query = "SELECT firstname, lastname FROM people WHERE lastname = ?";
        $cordovaSQLite.execute(db, query, [lastname]).then(function(res) {
            if(res.rows.length > 0) {
                console.log("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
                $scope.sqllitedata = "selected";
            } else {
                console.log("No results found");
                $scope.sqllitedata = err;
            }
        }, function (err) {
            console.error(err);
            $scope.sqllitedata = err;
        });
    }
 /*
  if (!angular.isUndefined(auth.profile) && auth.profile !== null )
  {

      $scope.profile_name = auth.profile.name;
      profile_auth0_name = auth.profile.name;
      $scope.pic = auth.profile.picture;

  
  }
  else
    $scope.profile_name = "Guest";
    */
 
  vm.login = login;
  
  vm.logout = logout;
  


  function login() {
      $state.go("login");

        
  }

  function logout() {
    /*
      auth.signout();

      store.remove('profile');
      store.remove('token');
      store.remove('accessToken');
      store.remove('refreshToken');
      */
      //$state.go('home.home2');
      $scope.profile_name = "Guest";
      $state.go($state.current, {}, {reload: true});
  }


 
 




}])  


 
 
 